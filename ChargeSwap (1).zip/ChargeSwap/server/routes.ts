import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertStationSchema,
  insertBatterySchema,
  insertSwapSchema,
  insertAlertSchema,
  insertOperatorCheckInSchema,
  insertQrCodeSchema,
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard metrics
  app.get('/api/dashboard/metrics', isAuthenticated, async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // Station routes
  app.get('/api/stations', isAuthenticated, async (req, res) => {
    try {
      const stations = await storage.getStations();
      res.json(stations);
    } catch (error) {
      console.error("Error fetching stations:", error);
      res.status(500).json({ message: "Failed to fetch stations" });
    }
  });

  app.get('/api/stations/:id', isAuthenticated, async (req, res) => {
    try {
      const station = await storage.getStation(req.params.id);
      if (!station) {
        return res.status(404).json({ message: "Station not found" });
      }
      res.json(station);
    } catch (error) {
      console.error("Error fetching station:", error);
      res.status(500).json({ message: "Failed to fetch station" });
    }
  });

  app.post('/api/stations', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertStationSchema.parse(req.body);
      const station = await storage.createStation(validatedData);
      res.status(201).json(station);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating station:", error);
      res.status(500).json({ message: "Failed to create station" });
    }
  });

  app.put('/api/stations/:id', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertStationSchema.partial().parse(req.body);
      const station = await storage.updateStation(req.params.id, validatedData);
      res.json(station);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating station:", error);
      res.status(500).json({ message: "Failed to update station" });
    }
  });

  app.delete('/api/stations/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteStation(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting station:", error);
      res.status(500).json({ message: "Failed to delete station" });
    }
  });

  // Battery routes
  app.get('/api/batteries', isAuthenticated, async (req, res) => {
    try {
      const batteries = await storage.getBatteries();
      res.json(batteries);
    } catch (error) {
      console.error("Error fetching batteries:", error);
      res.status(500).json({ message: "Failed to fetch batteries" });
    }
  });

  app.get('/api/batteries/:id', isAuthenticated, async (req, res) => {
    try {
      const battery = await storage.getBattery(req.params.id);
      if (!battery) {
        return res.status(404).json({ message: "Battery not found" });
      }
      res.json(battery);
    } catch (error) {
      console.error("Error fetching battery:", error);
      res.status(500).json({ message: "Failed to fetch battery" });
    }
  });

  app.post('/api/batteries', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertBatterySchema.parse(req.body);
      const battery = await storage.createBattery(validatedData);
      res.status(201).json(battery);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating battery:", error);
      res.status(500).json({ message: "Failed to create battery" });
    }
  });

  app.put('/api/batteries/:id', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertBatterySchema.partial().parse(req.body);
      const battery = await storage.updateBattery(req.params.id, validatedData);
      res.json(battery);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating battery:", error);
      res.status(500).json({ message: "Failed to update battery" });
    }
  });

  app.post('/api/batteries/:id/refresh-location', isAuthenticated, async (req, res) => {
    try {
      const battery = await storage.getBattery(req.params.id);
      if (!battery) {
        return res.status(404).json({ message: "Battery not found" });
      }
      
      // In a real application, this would trigger GPS/location refresh
      // For now, we'll just update the locationUpdatedAt timestamp
      const updatedBattery = await storage.updateBattery(req.params.id, {
        locationUpdatedAt: new Date(),
      });
      
      res.json(updatedBattery);
    } catch (error) {
      console.error("Error refreshing battery location:", error);
      res.status(500).json({ message: "Failed to refresh battery location" });
    }
  });

  app.delete('/api/batteries/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteBattery(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting battery:", error);
      res.status(500).json({ message: "Failed to delete battery" });
    }
  });

  app.get('/api/stations/:stationId/batteries', isAuthenticated, async (req, res) => {
    try {
      const batteries = await storage.getBatteriesByStation(req.params.stationId);
      res.json(batteries);
    } catch (error) {
      console.error("Error fetching station batteries:", error);
      res.status(500).json({ message: "Failed to fetch station batteries" });
    }
  });

  // Swap routes
  app.get('/api/swaps', isAuthenticated, async (req, res) => {
    try {
      const swaps = await storage.getSwaps();
      res.json(swaps);
    } catch (error) {
      console.error("Error fetching swaps:", error);
      res.status(500).json({ message: "Failed to fetch swaps" });
    }
  });

  app.post('/api/swaps', isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertSwapSchema.parse(req.body);
      const operatorId = req.user.claims.sub;
      const swap = await storage.createSwap({ ...validatedData, operatorId });
      res.status(201).json(swap);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating swap:", error);
      res.status(500).json({ message: "Failed to create swap" });
    }
  });

  app.get('/api/stations/:stationId/swaps', isAuthenticated, async (req, res) => {
    try {
      const swaps = await storage.getSwapsByStation(req.params.stationId);
      res.json(swaps);
    } catch (error) {
      console.error("Error fetching station swaps:", error);
      res.status(500).json({ message: "Failed to fetch station swaps" });
    }
  });

  // Alert routes
  app.get('/api/alerts', isAuthenticated, async (req, res) => {
    try {
      const alerts = await storage.getAlerts();
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.post('/api/alerts', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(validatedData);
      res.status(201).json(alert);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating alert:", error);
      res.status(500).json({ message: "Failed to create alert" });
    }
  });

  app.put('/api/alerts/:id/read', isAuthenticated, async (req, res) => {
    try {
      await storage.markAlertAsRead(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error marking alert as read:", error);
      res.status(500).json({ message: "Failed to mark alert as read" });
    }
  });

  // Operator check-in routes
  app.get('/api/operator-checkins', isAuthenticated, async (req, res) => {
    try {
      const checkIns = await storage.getOperatorCheckIns();
      res.json(checkIns);
    } catch (error) {
      console.error("Error fetching operator check-ins:", error);
      res.status(500).json({ message: "Failed to fetch operator check-ins" });
    }
  });

  app.post('/api/operator-checkins', isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertOperatorCheckInSchema.parse(req.body);
      const operatorId = req.user.claims.sub;
      const checkIn = await storage.createOperatorCheckIn({ ...validatedData, operatorId });
      res.status(201).json(checkIn);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating operator check-in:", error);
      res.status(500).json({ message: "Failed to create operator check-in" });
    }
  });

  app.put('/api/operator-checkins/:id/checkout', isAuthenticated, async (req, res) => {
    try {
      const checkOutTime = new Date();
      const checkIn = await storage.updateOperatorCheckIn(req.params.id, { checkOutTime });
      res.json(checkIn);
    } catch (error) {
      console.error("Error checking out operator:", error);
      res.status(500).json({ message: "Failed to check out operator" });
    }
  });

  // QR Code routes
  app.get('/api/qr-codes', isAuthenticated, async (req, res) => {
    try {
      const qrCodes = await storage.getQrCodes();
      res.json(qrCodes);
    } catch (error) {
      console.error("Error fetching QR codes:", error);
      res.status(500).json({ message: "Failed to fetch QR codes" });
    }
  });

  app.post('/api/qr-codes', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertQrCodeSchema.parse(req.body);
      const qrCode = await storage.createQrCode(validatedData);
      res.status(201).json(qrCode);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating QR code:", error);
      res.status(500).json({ message: "Failed to create QR code" });
    }
  });

  app.get('/api/qr-codes/:type/:entityId', isAuthenticated, async (req, res) => {
    try {
      const qrCode = await storage.getQrCodeByEntity(req.params.type, req.params.entityId);
      if (!qrCode) {
        return res.status(404).json({ message: "QR code not found" });
      }
      res.json(qrCode);
    } catch (error) {
      console.error("Error fetching QR code:", error);
      res.status(500).json({ message: "Failed to fetch QR code" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
