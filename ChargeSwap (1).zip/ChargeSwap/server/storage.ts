import {
  users,
  stations,
  batteries,
  swaps,
  alerts,
  operatorCheckIns,
  qrCodes,
  type User,
  type UpsertUser,
  type Station,
  type InsertStation,
  type Battery,
  type InsertBattery,
  type Swap,
  type InsertSwap,
  type Alert,
  type InsertAlert,
  type OperatorCheckIn,
  type InsertOperatorCheckIn,
  type QrCode,
  type InsertQrCode,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, count, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Station operations
  getStations(): Promise<Station[]>;
  getStation(id: string): Promise<Station | undefined>;
  createStation(station: InsertStation): Promise<Station>;
  updateStation(id: string, station: Partial<InsertStation>): Promise<Station>;
  deleteStation(id: string): Promise<void>;

  // Battery operations
  getBatteries(): Promise<Battery[]>;
  getBattery(id: string): Promise<Battery | undefined>;
  getBatteryByBatteryId(batteryId: string): Promise<Battery | undefined>;
  createBattery(battery: InsertBattery): Promise<Battery>;
  updateBattery(id: string, battery: Partial<InsertBattery>): Promise<Battery>;
  deleteBattery(id: string): Promise<void>;
  getBatteriesByStation(stationId: string): Promise<Battery[]>;
  getAvailableBatteriesCount(): Promise<number>;

  // Swap operations
  getSwaps(): Promise<Swap[]>;
  getSwap(id: string): Promise<Swap | undefined>;
  createSwap(swap: InsertSwap): Promise<Swap>;
  updateSwap(id: string, swap: Partial<InsertSwap>): Promise<Swap>;
  getSwapsByStation(stationId: string): Promise<Swap[]>;
  getTodaySwapsCount(): Promise<number>;

  // Alert operations
  getAlerts(): Promise<Alert[]>;
  getAlert(id: string): Promise<Alert | undefined>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: string, alert: Partial<InsertAlert>): Promise<Alert>;
  markAlertAsRead(id: string): Promise<void>;
  getUnreadAlertsCount(): Promise<number>;

  // Operator check-in operations
  getOperatorCheckIns(): Promise<OperatorCheckIn[]>;
  createOperatorCheckIn(checkIn: InsertOperatorCheckIn): Promise<OperatorCheckIn>;
  updateOperatorCheckIn(id: string, checkIn: Partial<InsertOperatorCheckIn>): Promise<OperatorCheckIn>;
  getActiveOperatorsCount(): Promise<number>;

  // QR code operations
  getQrCodes(): Promise<QrCode[]>;
  getQrCode(id: string): Promise<QrCode | undefined>;
  createQrCode(qrCode: InsertQrCode): Promise<QrCode>;
  getQrCodeByEntity(type: string, entityId: string): Promise<QrCode | undefined>;

  // Dashboard metrics
  getDashboardMetrics(): Promise<{
    totalStations: number;
    availableBatteries: number;
    dailySwaps: number;
    activeOperators: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Station operations
  async getStations(): Promise<Station[]> {
    return await db.select().from(stations).orderBy(desc(stations.createdAt));
  }

  async getStation(id: string): Promise<Station | undefined> {
    const [station] = await db.select().from(stations).where(eq(stations.id, id));
    return station;
  }

  async createStation(station: InsertStation): Promise<Station> {
    const [newStation] = await db.insert(stations).values(station).returning();
    return newStation;
  }

  async updateStation(id: string, station: Partial<InsertStation>): Promise<Station> {
    const [updatedStation] = await db
      .update(stations)
      .set({ ...station, updatedAt: new Date() })
      .where(eq(stations.id, id))
      .returning();
    return updatedStation;
  }

  async deleteStation(id: string): Promise<void> {
    await db.delete(stations).where(eq(stations.id, id));
  }

  // Battery operations
  async getBatteries(): Promise<Battery[]> {
    return await db.select().from(batteries).orderBy(desc(batteries.createdAt));
  }

  async getBattery(id: string): Promise<Battery | undefined> {
    const [battery] = await db.select().from(batteries).where(eq(batteries.id, id));
    return battery;
  }

  async getBatteryByBatteryId(batteryId: string): Promise<Battery | undefined> {
    const [battery] = await db.select().from(batteries).where(eq(batteries.batteryId, batteryId));
    return battery;
  }

  async createBattery(battery: InsertBattery): Promise<Battery> {
    const [newBattery] = await db.insert(batteries).values(battery).returning();
    return newBattery;
  }

  async updateBattery(id: string, battery: Partial<InsertBattery>): Promise<Battery> {
    const [updatedBattery] = await db
      .update(batteries)
      .set({ ...battery, updatedAt: new Date() })
      .where(eq(batteries.id, id))
      .returning();
    return updatedBattery;
  }

  async deleteBattery(id: string): Promise<void> {
    await db.delete(batteries).where(eq(batteries.id, id));
  }

  async getBatteriesByStation(stationId: string): Promise<Battery[]> {
    return await db.select().from(batteries).where(eq(batteries.stationId, stationId));
  }

  async getAvailableBatteriesCount(): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(batteries)
      .where(eq(batteries.status, "available"));
    return result.count;
  }

  // Swap operations
  async getSwaps(): Promise<Swap[]> {
    return await db.select().from(swaps).orderBy(desc(swaps.createdAt));
  }

  async getSwap(id: string): Promise<Swap | undefined> {
    const [swap] = await db.select().from(swaps).where(eq(swaps.id, id));
    return swap;
  }

  async createSwap(swap: InsertSwap): Promise<Swap> {
    const transactionId = `TXN-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.random().toString(36).substr(2, 3).toUpperCase()}`;
    const [newSwap] = await db.insert(swaps).values({ ...swap, transactionId }).returning();
    return newSwap;
  }

  async updateSwap(id: string, swap: Partial<InsertSwap>): Promise<Swap> {
    const [updatedSwap] = await db
      .update(swaps)
      .set(swap)
      .where(eq(swaps.id, id))
      .returning();
    return updatedSwap;
  }

  async getSwapsByStation(stationId: string): Promise<Swap[]> {
    return await db.select().from(swaps).where(eq(swaps.stationId, stationId));
  }

  async getTodaySwapsCount(): Promise<number> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [result] = await db
      .select({ count: count() })
      .from(swaps)
      .where(
        and(
          sql`${swaps.createdAt} >= ${today}`,
          sql`${swaps.createdAt} < ${tomorrow}`
        )
      );
    return result.count;
  }

  // Alert operations
  async getAlerts(): Promise<Alert[]> {
    return await db.select().from(alerts).orderBy(desc(alerts.createdAt));
  }

  async getAlert(id: string): Promise<Alert | undefined> {
    const [alert] = await db.select().from(alerts).where(eq(alerts.id, id));
    return alert;
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const [newAlert] = await db.insert(alerts).values(alert).returning();
    return newAlert;
  }

  async updateAlert(id: string, alert: Partial<InsertAlert>): Promise<Alert> {
    const [updatedAlert] = await db
      .update(alerts)
      .set(alert)
      .where(eq(alerts.id, id))
      .returning();
    return updatedAlert;
  }

  async markAlertAsRead(id: string): Promise<void> {
    await db.update(alerts).set({ isRead: true }).where(eq(alerts.id, id));
  }

  async getUnreadAlertsCount(): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(alerts)
      .where(eq(alerts.isRead, false));
    return result.count;
  }

  // Operator check-in operations
  async getOperatorCheckIns(): Promise<OperatorCheckIn[]> {
    return await db.select().from(operatorCheckIns).orderBy(desc(operatorCheckIns.checkInTime));
  }

  async createOperatorCheckIn(checkIn: InsertOperatorCheckIn): Promise<OperatorCheckIn> {
    const [newCheckIn] = await db.insert(operatorCheckIns).values(checkIn).returning();
    return newCheckIn;
  }

  async updateOperatorCheckIn(id: string, checkIn: Partial<InsertOperatorCheckIn>): Promise<OperatorCheckIn> {
    const [updatedCheckIn] = await db
      .update(operatorCheckIns)
      .set(checkIn)
      .where(eq(operatorCheckIns.id, id))
      .returning();
    return updatedCheckIn;
  }

  async getActiveOperatorsCount(): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(operatorCheckIns)
      .where(sql`${operatorCheckIns.checkOutTime} IS NULL`);
    return result.count;
  }

  // QR code operations
  async getQrCodes(): Promise<QrCode[]> {
    return await db.select().from(qrCodes).orderBy(desc(qrCodes.createdAt));
  }

  async getQrCode(id: string): Promise<QrCode | undefined> {
    const [qrCode] = await db.select().from(qrCodes).where(eq(qrCodes.id, id));
    return qrCode;
  }

  async createQrCode(qrCode: InsertQrCode): Promise<QrCode> {
    const [newQrCode] = await db.insert(qrCodes).values(qrCode).returning();
    return newQrCode;
  }

  async getQrCodeByEntity(type: string, entityId: string): Promise<QrCode | undefined> {
    const [qrCode] = await db
      .select()
      .from(qrCodes)
      .where(and(eq(qrCodes.type, type), eq(qrCodes.entityId, entityId)));
    return qrCode;
  }

  // Dashboard metrics
  async getDashboardMetrics(): Promise<{
    totalStations: number;
    availableBatteries: number;
    dailySwaps: number;
    activeOperators: number;
  }> {
    const [stationsCount] = await db.select({ count: count() }).from(stations);
    const [batteriesCount] = await db
      .select({ count: count() })
      .from(batteries)
      .where(eq(batteries.status, "available"));
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [swapsCount] = await db
      .select({ count: count() })
      .from(swaps)
      .where(
        and(
          sql`${swaps.createdAt} >= ${today}`,
          sql`${swaps.createdAt} < ${tomorrow}`
        )
      );

    const [operatorsCount] = await db
      .select({ count: count() })
      .from(operatorCheckIns)
      .where(sql`${operatorCheckIns.checkOutTime} IS NULL`);

    return {
      totalStations: stationsCount.count,
      availableBatteries: batteriesCount.count,
      dailySwaps: swapsCount.count,
      activeOperators: operatorsCount.count,
    };
  }
}

export const storage = new DatabaseStorage();
