import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { QrCode, Download, Printer, Copy, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { QrCode as QrCodeType } from "@shared/schema";

interface QrModalProps {
  qrCode: QrCodeType | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function QrModal({ qrCode, open, onOpenChange }: QrModalProps) {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);

  const handleCopyData = async () => {
    if (!qrCode) return;
    
    try {
      await navigator.clipboard.writeText(qrCode.qrData);
      toast({
        title: "Copied!",
        description: "QR code data copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy QR code data to clipboard.",
        variant: "destructive",
      });
    }
  };

  const handleDownload = () => {
    if (!qrCode) return;
    
    // Create a simple QR-like visual representation for download
    // In a real implementation, you would use a QR code library like 'qrcode' or 'react-qr-code'
    const canvas = document.createElement('canvas');
    canvas.width = 200;
    canvas.height = 200;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      // White background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, 200, 200);
      
      // Create a simple pattern to represent QR code
      ctx.fillStyle = '#000000';
      for (let i = 0; i < 20; i++) {
        for (let j = 0; j < 20; j++) {
          if (Math.random() > 0.5) {
            ctx.fillRect(i * 10, j * 10, 10, 10);
          }
        }
      }
      
      // Add corner markers
      ctx.fillRect(0, 0, 70, 70);
      ctx.fillRect(130, 0, 70, 70);
      ctx.fillRect(0, 130, 70, 70);
      
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(10, 10, 50, 50);
      ctx.fillRect(140, 10, 50, 50);
      ctx.fillRect(10, 140, 50, 50);
      
      ctx.fillStyle = '#000000';
      ctx.fillRect(20, 20, 30, 30);
      ctx.fillRect(150, 20, 30, 30);
      ctx.fillRect(20, 150, 30, 30);
    }
    
    // Download the canvas as image
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `qr-${qrCode.type}-${qrCode.entityId}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        toast({
          title: "Downloaded!",
          description: "QR code image has been downloaded.",
        });
      }
    });
  };

  const handlePrint = () => {
    if (!qrCode) return;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>QR Code - ${qrCode.entityId}</title>
            <style>
              body { 
                font-family: Arial, sans-serif; 
                padding: 20px; 
                text-align: center; 
              }
              .qr-container { 
                border: 2px solid #000; 
                width: 200px; 
                height: 200px; 
                margin: 20px auto; 
                display: flex; 
                align-items: center; 
                justify-content: center;
                background: linear-gradient(45deg, #f0f0f0 25%, transparent 25%), 
                           linear-gradient(-45deg, #f0f0f0 25%, transparent 25%), 
                           linear-gradient(45deg, transparent 75%, #f0f0f0 75%), 
                           linear-gradient(-45deg, transparent 75%, #f0f0f0 75%);
                background-size: 20px 20px;
                background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
              }
              .info { margin-top: 20px; }
              @media print {
                body { margin: 0; }
              }
            </style>
          </head>
          <body>
            <h2>QR Code for ${qrCode.type}: ${qrCode.entityId}</h2>
            <div class="qr-container">
              <div style="font-size: 48px;">⬜</div>
            </div>
            <div class="info">
              <p><strong>Type:</strong> ${qrCode.type}</p>
              <p><strong>Entity ID:</strong> ${qrCode.entityId}</p>
              <p><strong>Data:</strong> ${qrCode.qrData}</p>
              <p><strong>Generated:</strong> ${new Date(qrCode.createdAt!).toLocaleString()}</p>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
    
    toast({
      title: "Print Ready",
      description: "QR code print dialog opened.",
    });
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "battery":
        return "bg-green-100 text-green-800";
      case "station":
        return "bg-blue-100 text-blue-800";
      case "slot":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center space-x-2">
              <QrCode className="w-5 h-5" />
              <span>QR Code Details</span>
            </DialogTitle>
          </div>
        </DialogHeader>
        
        {qrCode && (
          <div className="space-y-6">
            {/* QR Code Display */}
            <div className="text-center">
              <div className="w-48 h-48 bg-gray-100 mx-auto mb-4 flex items-center justify-center rounded-lg border-2 border-gray-200 relative overflow-hidden">
                {/* Simulated QR Code Pattern */}
                <div className="absolute inset-0 opacity-20">
                  <div className="grid grid-cols-12 h-full">
                    {[...Array(144)].map((_, i) => (
                      <div
                        key={i}
                        className={`${Math.random() > 0.5 ? 'bg-black' : 'bg-white'}`}
                      />
                    ))}
                  </div>
                </div>
                
                {/* Corner markers */}
                <div className="absolute top-2 left-2 w-8 h-8 border-2 border-black">
                  <div className="w-4 h-4 bg-black m-1"></div>
                </div>
                <div className="absolute top-2 right-2 w-8 h-8 border-2 border-black">
                  <div className="w-4 h-4 bg-black m-1"></div>
                </div>
                <div className="absolute bottom-2 left-2 w-8 h-8 border-2 border-black">
                  <div className="w-4 h-4 bg-black m-1"></div>
                </div>
                
                <div className="text-center text-gray-600 z-10">
                  <QrCode className="w-12 h-12 mx-auto mb-2" />
                  <p className="text-sm font-medium">{qrCode.type.toUpperCase()}</p>
                  <p className="text-xs">{qrCode.entityId}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-center space-x-2">
                  <span className="text-sm font-medium">Type:</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(qrCode.type)}`}>
                    {qrCode.type}
                  </span>
                </div>
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Entity ID:</span> {qrCode.entityId}
                </p>
                <p className="text-xs text-gray-500 font-mono bg-gray-50 p-2 rounded break-all">
                  {qrCode.qrData}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-3 gap-3">
              <Button
                variant="outline"
                className="flex flex-col items-center py-3 h-auto"
                onClick={handleCopyData}
              >
                <Copy className="w-4 h-4 mb-1" />
                <span className="text-xs">Copy Data</span>
              </Button>
              
              <Button
                variant="outline"
                className="flex flex-col items-center py-3 h-auto"
                onClick={handleDownload}
              >
                <Download className="w-4 h-4 mb-1" />
                <span className="text-xs">Download</span>
              </Button>
              
              <Button
                variant="outline"
                className="flex flex-col items-center py-3 h-auto"
                onClick={handlePrint}
              >
                <Printer className="w-4 h-4 mb-1" />
                <span className="text-xs">Print</span>
              </Button>
            </div>

            {/* Metadata */}
            <div className="text-xs text-gray-500 text-center space-y-1 pt-4 border-t border-gray-200">
              <p>Generated: {new Date(qrCode.createdAt!).toLocaleString()}</p>
              <p className="font-mono">ID: {qrCode.id}</p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
