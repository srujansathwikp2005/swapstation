import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Battery, Search, Plus, Eye, QrCode, ChevronLeft, ChevronRight } from "lucide-react";
import BatteryForm from "@/components/forms/battery-form";
import QrModal from "@/components/qr/qr-modal";
import type { Battery as BatteryType, QrCode as QrCodeType } from "@shared/schema";

interface BatteryTableProps {
  showFullInterface?: boolean;
}

export default function BatteryTable({ showFullInterface = false }: BatteryTableProps) {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [showBatteryForm, setShowBatteryForm] = useState(false);
  const [selectedQrCode, setSelectedQrCode] = useState<QrCodeType | null>(null);
  const itemsPerPage = showFullInterface ? 10 : 5;

  const { data: batteries = [], isLoading, error } = useQuery({
    queryKey: ["/api/batteries"],
  });

  const generateQrMutation = useMutation({
    mutationFn: async (batteryId: string) => {
      const qrData = `battery:${batteryId}:${Date.now()}`;
      return await apiRequest("POST", "/api/qr-codes", {
        type: "battery",
        entityId: batteryId,
        qrData: qrData,
      });
    },
    onSuccess: async (response) => {
      const qrCode = await response.json();
      setSelectedQrCode(qrCode);
      queryClient.invalidateQueries({ queryKey: ["/api/qr-codes"] });
      toast({
        title: "QR Code Generated",
        description: "QR code has been generated successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate QR code. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  const filteredBatteries = (batteries as BatteryType[]).filter((battery: BatteryType) => {
    const matchesSearch = battery.batteryId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || battery.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalPages = Math.ceil(filteredBatteries.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedBatteries = filteredBatteries.slice(startIndex, startIndex + itemsPerPage);

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "available":
        return "default";
      case "charging":
        return "secondary";
      case "in_use":
        return "outline";
      case "maintenance":
        return "destructive";
      default:
        return "outline";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800";
      case "charging":
        return "bg-yellow-100 text-yellow-800";
      case "in_use":
        return "bg-blue-100 text-blue-800";
      case "maintenance":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getBatteryIcon = (status: string) => {
    switch (status) {
      case "available":
        return "text-green-600";
      case "charging":
        return "text-yellow-600";
      case "in_use":
        return "text-blue-600";
      case "maintenance":
        return "text-red-600";
      default:
        return "text-gray-600";
    }
  };

  const getChargeColor = (level: number) => {
    if (level >= 80) return "bg-green-500";
    if (level >= 50) return "bg-yellow-500";
    if (level >= 20) return "bg-orange-500";
    return "bg-red-500";
  };

  const handleGenerateQr = (batteryId: string) => {
    generateQrMutation.mutate(batteryId);
  };

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>
              {showFullInterface ? "Battery Management" : "Battery Overview"}
            </CardTitle>
            {showFullInterface && (
              <Button onClick={() => setShowBatteryForm(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Register Battery
              </Button>
            )}
          </div>
          {showFullInterface && (
            <div className="flex items-center space-x-3 mt-4">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search batteries..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="charging">Charging</SelectItem>
                  <SelectItem value="in_use">In Use</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(itemsPerPage)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="flex items-center space-x-4 p-4 border-b border-gray-200">
                    <div className="w-8 h-8 bg-gray-200 rounded-lg"></div>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-32"></div>
                      <div className="h-3 bg-gray-200 rounded w-24"></div>
                    </div>
                    <div className="h-6 bg-gray-200 rounded w-20"></div>
                    <div className="h-8 bg-gray-200 rounded w-16"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Battery ID</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Charge Level</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedBatteries.length > 0 ? (
                      paginatedBatteries.map((battery: BatteryType) => (
                        <TableRow key={battery.id} className="hover:bg-gray-50">
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <div className={`w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center`}>
                                <Battery className={`w-4 h-4 ${getBatteryIcon(battery.status)}`} />
                              </div>
                              <span className="font-mono font-medium">{battery.batteryId}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(battery.status)}>
                              {battery.status.replace('_', ' ')}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <div className="w-16 bg-gray-200 rounded-full h-2">
                                <div 
                                  className={`h-2 rounded-full ${getChargeColor(battery.chargeLevel)}`}
                                  style={{ width: `${battery.chargeLevel}%` }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium">{battery.chargeLevel}%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {battery.stationId ? (
                              battery.slotNumber ? 
                                `Station ${battery.stationId.slice(-3)} - Slot ${battery.slotNumber}` :
                                `Station ${battery.stationId.slice(-3)}`
                            ) : (
                              "Unassigned"
                            )}
                          </TableCell>
                          <TableCell className="text-sm text-gray-500">
                            {battery.updatedAt ? new Date(battery.updatedAt).toLocaleString() : "N/A"}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
                                <Eye className="w-3 h-3 mr-1" />
                                View
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-orange-600 hover:text-orange-700"
                                onClick={() => handleGenerateQr(battery.batteryId)}
                                disabled={generateQrMutation.isPending}
                              >
                                <QrCode className="w-3 h-3 mr-1" />
                                QR Code
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-12">
                          <Battery className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">No batteries found</h3>
                          <p className="text-gray-600 mb-4">
                            {searchTerm || statusFilter !== "all" 
                              ? "No batteries match your search criteria." 
                              : "Get started by registering your first battery."
                            }
                          </p>
                          {showFullInterface && (
                            <Button onClick={() => setShowBatteryForm(true)} className="bg-blue-600 hover:bg-blue-700">
                              <Plus className="w-4 h-4 mr-2" />
                              Register Battery
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {showFullInterface && totalPages > 1 && (
                <div className="flex items-center justify-between mt-6 pt-4 border-t border-gray-200">
                  <div className="text-sm text-gray-700">
                    Showing {startIndex + 1} to {Math.min(startIndex + itemsPerPage, filteredBatteries.length)} of{' '}
                    {filteredBatteries.length} results
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Previous
                    </Button>
                    <div className="flex items-center space-x-1">
                      {[...Array(Math.min(5, totalPages))].map((_, i) => {
                        const page = i + 1;
                        return (
                          <Button
                            key={page}
                            variant={currentPage === page ? "default" : "outline"}
                            size="sm"
                            onClick={() => setCurrentPage(page)}
                            className={currentPage === page ? "bg-blue-600 hover:bg-blue-700" : ""}
                          >
                            {page}
                          </Button>
                        );
                      })}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                    >
                      Next
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <BatteryForm 
        open={showBatteryForm}
        onOpenChange={setShowBatteryForm}
      />

      <QrModal
        qrCode={selectedQrCode}
        open={!!selectedQrCode}
        onOpenChange={(open) => !open && setSelectedQrCode(null)}
      />
    </>
  );
}
