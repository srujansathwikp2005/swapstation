import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  MapPin, 
  Navigation, 
  Clock, 
  Thermometer, 
  Battery as BatteryIcon,
  TrendingUp,
  TrendingDown,
  Minus,
  Search,
  Filter,
  RefreshCw
} from "lucide-react";
import { Battery as BatteryType } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function BatteryLocationTracker() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: batteries, isLoading, error } = useQuery({
    queryKey: ["/api/batteries"],
  });

  const refreshLocationMutation = useMutation({
    mutationFn: async (batteryId: string) => {
      return apiRequest(`/api/batteries/${batteryId}/refresh-location`, "POST");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/batteries"] });
      toast({
        title: "Success",
        description: "Battery location refreshed successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to refresh location. Please try again.",
        variant: "destructive",
      });
    },
  });

  const filteredBatteries = (batteries as BatteryType[] || []).filter((battery: BatteryType) => {
    const matchesSearch = battery.batteryId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (battery.lastKnownLocation || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || battery.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800";
      case "charging":
        return "bg-yellow-100 text-yellow-800";
      case "in_use":
        return "bg-blue-100 text-blue-800";
      case "in_transit":
        return "bg-purple-100 text-purple-800";
      case "maintenance":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getLocationIcon = (status: string) => {
    switch (status) {
      case "in_transit":
        return <Navigation className="w-4 h-4" />;
      default:
        return <MapPin className="w-4 h-4" />;
    }
  };

  const formatLastUpdate = (date: Date | string | null) => {
    if (!date) return "Never";
    const updateDate = new Date(date);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - updateDate.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  const getHealthTrend = (health: number | null) => {
    if (!health) return <Minus className="w-4 h-4 text-gray-400" />;
    if (health >= 90) return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (health >= 70) return <Minus className="w-4 h-4 text-yellow-600" />;
    return <TrendingDown className="w-4 h-4 text-red-600" />;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Battery Location Tracking</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="h-5 bg-gray-200 rounded w-32"></div>
                  <div className="h-6 bg-gray-200 rounded w-20"></div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[...Array(4)].map((_, j) => (
                    <div key={j} className="space-y-2">
                      <div className="h-3 bg-gray-200 rounded w-16"></div>
                      <div className="h-4 bg-gray-200 rounded w-24"></div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Battery Location Tracking</CardTitle>
            <Button 
              onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/batteries"] })}
              variant="outline" 
              size="sm"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Search and Filter */}
          <div className="flex space-x-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by battery ID or location..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border rounded-md px-3 py-2 text-sm"
              >
                <option value="all">All Status</option>
                <option value="available">Available</option>
                <option value="charging">Charging</option>
                <option value="in_use">In Use</option>
                <option value="in_transit">In Transit</option>
                <option value="maintenance">Maintenance</option>
              </select>
            </div>
          </div>

          {filteredBatteries.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No batteries found</h3>
              <p className="text-gray-500">Try adjusting your search or filter criteria.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredBatteries.map((battery: BatteryType) => (
                <div 
                  key={battery.id} 
                  className="relative border rounded-lg p-4 hover:border-blue-300 transition-colors overflow-hidden"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23f8fafc' fill-opacity='0.3'%3E%3Ccircle cx='3' cy='3' r='1'/%3E%3Ccircle cx='13' cy='13' r='1'/%3E%3Ccircle cx='23' cy='23' r='1'/%3E%3Ccircle cx='33' cy='33' r='1'/%3E%3Ccircle cx='43' cy='43' r='1'/%3E%3Ccircle cx='53' cy='53' r='1'/%3E%3Ccircle cx='53' cy='3' r='1'/%3E%3Ccircle cx='43' cy='13' r='1'/%3E%3Ccircle cx='33' cy='23' r='1'/%3E%3Ccircle cx='23' cy='33' r='1'/%3E%3Ccircle cx='13' cy='43' r='1'/%3E%3Ccircle cx='3' cy='53' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                    backgroundSize: '60px 60px'
                  }}
                >
                  <div className="relative z-10 flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center shadow-sm">
                        <BatteryIcon className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900 font-mono">{battery.batteryId}</h3>
                        <p className="text-sm text-gray-500">
                          Last updated: {formatLastUpdate(battery.locationUpdatedAt)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(battery.status)}>
                        {battery.status}
                      </Badge>
                      <Button
                        onClick={() => refreshLocationMutation.mutate(battery.id)}
                        disabled={refreshLocationMutation.isPending}
                        variant="outline"
                        size="sm"
                      >
                        <RefreshCw className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>

                  <div className="relative z-10 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-1 text-gray-500">
                        {getLocationIcon(battery.status)}
                        <span>Location</span>
                      </div>
                      <p className="font-medium text-gray-900">
                        {battery.lastKnownLocation || "Unknown"}
                      </p>
                      {battery.latitude && battery.longitude && (
                        <p className="text-xs text-gray-500 font-mono">
                          {parseFloat(battery.latitude as string).toFixed(4)}, {parseFloat(battery.longitude as string).toFixed(4)}
                        </p>
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center space-x-1 text-gray-500">
                        <BatteryIcon className="w-4 h-4" />
                        <span>Charge</span>
                      </div>
                      <p className="font-medium text-gray-900">{battery.chargeLevel}%</p>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center space-x-1 text-gray-500">
                        <Thermometer className="w-4 h-4" />
                        <span>Temperature</span>
                      </div>
                      <p className="font-medium text-gray-900">
                        {battery.temperatureCelsius ? `${battery.temperatureCelsius}°C` : "N/A"}
                      </p>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center space-x-1 text-gray-500">
                        {getHealthTrend(battery.healthPercentage)}
                        <span>Health</span>
                      </div>
                      <p className="font-medium text-gray-900">
                        {battery.healthPercentage ? `${battery.healthPercentage}%` : "N/A"}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}