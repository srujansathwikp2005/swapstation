import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  MapPin, 
  Battery, 
  ArrowRightLeft, 
  Users, 
  QrCode, 
  BarChart3, 
  Bell,
  LogOut,
  User as UserIcon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navigation = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard },
    { name: "Stations", href: "/stations", icon: MapPin },
    { name: "Batteries", href: "/batteries", icon: Battery },
    { name: "Swap History", href: "/swap-history", icon: ArrowRightLeft },
    { name: "Operators", href: "/operators", icon: Users },
    { name: "QR Codes", href: "/qr-codes", icon: QrCode },
  ];

  const analyticsNav = [
    { name: "Reports", href: "/reports", icon: BarChart3 },
    { name: "Alerts", href: "/alerts", icon: Bell },
  ];

  return (
    <aside className="w-64 bg-white shadow-lg border-r border-gray-200 fixed h-full z-40">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <Battery className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">EnergySwap</h1>
            <p className="text-sm text-gray-500">Pro Dashboard</p>
          </div>
        </div>
      </div>
      
      <nav className="mt-6 px-3">
        <div className="space-y-1">
          {navigation.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.name} href={item.href}>
                <a
                  className={`
                    group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors
                    ${isActive 
                      ? 'bg-blue-50 text-blue-600' 
                      : 'text-gray-700 hover:bg-gray-50'
                    }
                  `}
                >
                  <item.icon className={`mr-3 h-4 w-4 ${isActive ? 'text-blue-500' : 'text-gray-400'}`} />
                  {item.name}
                </a>
              </Link>
            );
          })}
        </div>
        
        <div className="mt-8">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Analytics
          </h3>
          <div className="mt-2 space-y-1">
            {analyticsNav.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.name} href={item.href}>
                  <a
                    className={`
                      group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors
                      ${isActive 
                        ? 'bg-blue-50 text-blue-600' 
                        : 'text-gray-700 hover:bg-gray-50'
                      }
                    `}
                  >
                    <item.icon className={`mr-3 h-4 w-4 ${isActive ? 'text-blue-500' : 'text-gray-400'}`} />
                    {item.name}
                  </a>
                </Link>
              );
            })}
          </div>
        </div>
      </nav>
      
      <div className="absolute bottom-0 w-full p-4">
        <div className="bg-gray-50 rounded-lg p-3">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              {(user as any)?.profileImageUrl ? (
                <img 
                  src={(user as any).profileImageUrl} 
                  alt="Profile" 
                  className="w-8 h-8 rounded-full object-cover"
                />
              ) : (
                <UserIcon className="w-4 h-4 text-gray-600" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {(user as any)?.firstName || (user as any)?.email || "Admin User"}
              </p>
              <p className="text-xs text-gray-500 truncate capitalize">
                {(user as any)?.role || "Administrator"}
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.location.href = "/api/logout"}
              className="text-gray-400 hover:text-gray-600 p-1"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </aside>
  );
}
