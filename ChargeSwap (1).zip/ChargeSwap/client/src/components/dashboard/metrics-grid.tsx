import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Battery, ArrowRightLeft, Users, TrendingUp, CheckCircle } from "lucide-react";

export default function MetricsGrid() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  const metricCards = [
    {
      title: "Total Stations",
      value: (metrics as any)?.totalStations || 0,
      icon: MapPin,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      trend: "+3 this month",
      trendIcon: TrendingUp,
      trendColor: "text-green-600",
    },
    {
      title: "Available Batteries",
      value: (metrics as any)?.availableBatteries || 0,
      icon: Battery,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      trend: "89% charged",
      trendIcon: CheckCircle,
      trendColor: "text-green-600",
    },
    {
      title: "Daily Swaps",
      value: (metrics as any)?.dailySwaps || 0,
      icon: ArrowRightLeft,
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      trend: "+15% vs yesterday",
      trendIcon: TrendingUp,
      trendColor: "text-orange-600",
    },
    {
      title: "Active Operators",
      value: (metrics as any)?.activeOperators || 0,
      icon: Users,
      iconBg: "bg-gray-100",
      iconColor: "text-gray-600",
      trend: "Current shift",
      trendIcon: Users,
      trendColor: "text-gray-500",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metricCards.map((metric) => (
        <Card key={metric.title} className="hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                {isLoading ? (
                  <div className="h-8 bg-gray-200 rounded w-16 mt-2 animate-pulse"></div>
                ) : (
                  <p className="text-3xl font-bold text-gray-900 mt-2">{metric.value.toLocaleString()}</p>
                )}
                <p className={`text-sm mt-1 flex items-center ${metric.trendColor}`}>
                  <metric.trendIcon className="w-3 h-3 mr-1" />
                  <span>{metric.trend}</span>
                </p>
              </div>
              <div className={`w-12 h-12 ${metric.iconBg} rounded-lg flex items-center justify-center`}>
                <metric.icon className={`w-6 h-6 ${metric.iconColor}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
