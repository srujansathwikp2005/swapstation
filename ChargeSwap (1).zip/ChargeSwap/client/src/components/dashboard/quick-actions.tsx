import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Battery, QrCode, BarChart3 } from "lucide-react";
import StationForm from "@/components/forms/station-form";
import BatteryForm from "@/components/forms/battery-form";

export default function QuickActions() {
  const [showStationForm, setShowStationForm] = useState(false);
  const [showBatteryForm, setShowBatteryForm] = useState(false);

  const actions = [
    {
      label: "Register New Station",
      icon: Plus,
      color: "border-blue-200 text-blue-600 hover:bg-blue-50",
      onClick: () => setShowStationForm(true),
    },
    {
      label: "Register Battery",
      icon: Battery,
      color: "border-green-200 text-green-600 hover:bg-green-50",
      onClick: () => setShowBatteryForm(true),
    },
    {
      label: "Generate QR Code",
      icon: QrCode,
      color: "border-orange-200 text-orange-600 hover:bg-orange-50",
      onClick: () => {
        // TODO: Implement QR code generation
        console.log("Generate QR code");
      },
    },
    {
      label: "View Reports",
      icon: BarChart3,
      color: "border-gray-200 text-gray-600 hover:bg-gray-50",
      onClick: () => {
        // TODO: Navigate to reports
        console.log("View reports");
      },
    },
  ];

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {actions.map((action) => (
              <Button
                key={action.label}
                variant="outline"
                className={`w-full justify-center ${action.color} transition-colors`}
                onClick={action.onClick}
              >
                <action.icon className="w-4 h-4 mr-2" />
                {action.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <StationForm 
        open={showStationForm}
        onOpenChange={setShowStationForm}
      />

      <BatteryForm 
        open={showBatteryForm}
        onOpenChange={setShowBatteryForm}
      />
    </>
  );
}
