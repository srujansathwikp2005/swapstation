import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { MapPin } from "lucide-react";
import type { Station } from "@shared/schema";

export default function StationStatus() {
  const { data: stations = [], isLoading } = useQuery({
    queryKey: ["/api/stations"],
  });

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "online":
        return "default";
      case "offline":
        return "destructive";
      case "maintenance":
        return "secondary";
      default:
        return "default";
    }
  };

  const getCapacityPercentage = (available: number, total: number) => {
    return total > 0 ? (available / total) * 100 : 0;
  };

  const getCapacityColor = (percentage: number) => {
    if (percentage >= 60) return "bg-green-500";
    if (percentage >= 30) return "bg-orange-500";
    return "bg-red-500";
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Real-time Station Status</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse-dot"></div>
            <span className="text-sm text-gray-500">Live</span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="border border-gray-200 rounded-lg p-4 animate-pulse">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                    <div className="space-y-1">
                      <div className="h-4 bg-gray-200 rounded w-24"></div>
                      <div className="h-3 bg-gray-200 rounded w-16"></div>
                    </div>
                  </div>
                  <div className="h-6 bg-gray-200 rounded w-16"></div>
                </div>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 rounded"></div>
                  <div className="h-2 bg-gray-200 rounded"></div>
                  <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(stations as Station[]).slice(0, 4).map((station: Station) => {
              // Mock data for demonstration - in real app this would come from API
              const availableSlots = Math.floor(Math.random() * station.capacity);
              const capacityPercentage = getCapacityPercentage(availableSlots, station.capacity);
              
              return (
                <div 
                  key={station.id} 
                  className="relative border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors cursor-pointer overflow-hidden"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg width='80' height='80' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23f1f5f9' fill-opacity='0.4'%3E%3Cpath d='M40 0h2L36 36 0 40v-2l36-36zm44 2v2L48 40l36 36v2h-2L44 42l36-36zM2 40h2l36 36v2H38l-36-36z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                    backgroundSize: '80px 80px'
                  }}
                >
                  <div className="relative z-10 flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center shadow-sm">
                        <MapPin className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">{station.name}</h3>
                        <p className="text-sm text-gray-500 font-mono">{station.code}</p>
                      </div>
                    </div>
                    <Badge variant={getStatusVariant(station.status)}>
                      {station.status}
                    </Badge>
                  </div>
                  
                  <div className="relative z-10 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Available Slots</span>
                      <span className="font-medium text-gray-900">{availableSlots}/{station.capacity}</span>
                    </div>
                    <Progress 
                      value={capacityPercentage} 
                      className="h-2"
                    />
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>Last swap: {Math.floor(Math.random() * 10) + 1} min ago</span>
                      <span>{Math.round(capacityPercentage)}% capacity</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
