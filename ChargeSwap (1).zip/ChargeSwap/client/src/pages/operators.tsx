import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Clock, MapPin } from "lucide-react";
import type { OperatorCheckIn } from "@shared/schema";

export default function Operators() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  const { data: checkIns = [], isLoading: checkInsLoading, error } = useQuery({
    queryKey: ["/api/operator-checkins"],
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const activeCheckIns = (checkIns as OperatorCheckIn[]).filter((checkIn: OperatorCheckIn) => !checkIn.checkOutTime);
  const completedCheckIns = (checkIns as OperatorCheckIn[]).filter((checkIn: OperatorCheckIn) => checkIn.checkOutTime);

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 ml-64">
        <Header 
          title="Operator Management"
          subtitle="Monitor operator check-ins and shift management"
        />
        
        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Active Operators */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span>Active Operators ({activeCheckIns.length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {checkInsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse border-b border-gray-200 pb-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                          <div className="space-y-2">
                            <div className="h-4 bg-gray-200 rounded w-32"></div>
                            <div className="h-3 bg-gray-200 rounded w-24"></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : activeCheckIns.length > 0 ? (
                  <div className="space-y-4">
                    {activeCheckIns.map((checkIn: OperatorCheckIn) => (
                      <div key={checkIn.id} className="border-b border-gray-200 pb-4 last:border-b-0">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-green-600" />
                            </div>
                            <div>
                              <h3 className="font-medium text-gray-900">{checkIn.operatorId}</h3>
                              <div className="flex items-center space-x-2 text-sm text-gray-500">
                                <MapPin className="w-3 h-3" />
                                <span>{checkIn.stationId}</span>
                              </div>
                            </div>
                          </div>
                          <Badge variant="default" className="bg-green-100 text-green-800">
                            Active
                          </Badge>
                        </div>
                        <div className="mt-2 flex items-center space-x-2 text-sm text-gray-600">
                          <Clock className="w-4 h-4" />
                          <span>Started: {new Date(checkIn.checkInTime!).toLocaleString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <User className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No active operators</h3>
                    <p className="text-gray-600">All operators are currently checked out.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Check-outs */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Check-outs</CardTitle>
              </CardHeader>
              <CardContent>
                {checkInsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse border-b border-gray-200 pb-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                          <div className="space-y-2">
                            <div className="h-4 bg-gray-200 rounded w-32"></div>
                            <div className="h-3 bg-gray-200 rounded w-24"></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : completedCheckIns.length > 0 ? (
                  <div className="space-y-4">
                    {completedCheckIns.slice(0, 5).map((checkIn: OperatorCheckIn) => (
                      <div key={checkIn.id} className="border-b border-gray-200 pb-4 last:border-b-0">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-gray-600" />
                            </div>
                            <div>
                              <h3 className="font-medium text-gray-900">{checkIn.operatorId}</h3>
                              <div className="flex items-center space-x-2 text-sm text-gray-500">
                                <MapPin className="w-3 h-3" />
                                <span>{checkIn.stationId}</span>
                              </div>
                            </div>
                          </div>
                          <Badge variant="secondary">
                            Completed
                          </Badge>
                        </div>
                        <div className="mt-2 space-y-1">
                          <div className="flex items-center space-x-2 text-sm text-gray-600">
                            <Clock className="w-4 h-4" />
                            <span>Check-in: {new Date(checkIn.checkInTime!).toLocaleString()}</span>
                          </div>
                          {checkIn.checkOutTime && (
                            <div className="flex items-center space-x-2 text-sm text-gray-600">
                              <Clock className="w-4 h-4" />
                              <span>Check-out: {new Date(checkIn.checkOutTime).toLocaleString()}</span>
                            </div>
                          )}
                          {checkIn.shiftDuration && (
                            <div className="text-sm text-gray-600">
                              Duration: {Math.floor(checkIn.shiftDuration / 60)}h {checkIn.shiftDuration % 60}m
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <User className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No check-outs yet</h3>
                    <p className="text-gray-600">Completed shifts will appear here.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
