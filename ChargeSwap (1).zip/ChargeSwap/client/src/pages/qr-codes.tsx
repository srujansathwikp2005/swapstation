import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { QrCode, Download, Eye } from "lucide-react";
import QrModal from "@/components/qr/qr-modal";
import type { QrCode as QrCodeType } from "@shared/schema";

export default function QrCodes() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedQrCode, setSelectedQrCode] = useState<QrCodeType | null>(null);

  const { data: qrCodes = [], isLoading: qrCodesLoading, error } = useQuery({
    queryKey: ["/api/qr-codes"],
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "battery":
        return "bg-green-100 text-green-800";
      case "station":
        return "bg-blue-100 text-blue-800";
      case "slot":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 ml-64">
        <Header 
          title="QR Code Management"
          subtitle="Generate and manage QR codes for batteries, stations, and slots"
        />
        
        <div className="p-6">
          <Card>
            <CardHeader>
              <CardTitle>Generated QR Codes</CardTitle>
            </CardHeader>
            <CardContent>
              {qrCodesLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="animate-pulse border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                        <div className="h-6 bg-gray-200 rounded w-16"></div>
                      </div>
                      <div className="h-20 bg-gray-200 rounded mb-3"></div>
                      <div className="h-8 bg-gray-200 rounded"></div>
                    </div>
                  ))}
                </div>
              ) : (qrCodes as QrCodeType[]).length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {(qrCodes as QrCodeType[]).map((qrCode: QrCodeType) => (
                    <div key={qrCode.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-medium text-gray-900">{qrCode.entityId}</h3>
                        <Badge className={getTypeColor(qrCode.type)}>
                          {qrCode.type}
                        </Badge>
                      </div>
                      
                      <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                        <QrCode className="w-12 h-12 text-gray-400" />
                      </div>
                      
                      <div className="text-xs text-gray-500 mb-3 font-mono truncate">
                        {qrCode.qrData}
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={() => setSelectedQrCode(qrCode)}
                        >
                          <Eye className="w-3 h-3 mr-1" />
                          View
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                        >
                          <Download className="w-3 h-3 mr-1" />
                          Download
                        </Button>
                      </div>
                      
                      <div className="text-xs text-gray-500 mt-2">
                        Created: {new Date(qrCode.createdAt!).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <QrCode className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No QR codes generated</h3>
                  <p className="text-gray-600">QR codes for batteries, stations, and slots will appear here.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      <QrModal
        qrCode={selectedQrCode}
        open={!!selectedQrCode}
        onOpenChange={(open) => !open && setSelectedQrCode(null)}
      />
    </div>
  );
}
