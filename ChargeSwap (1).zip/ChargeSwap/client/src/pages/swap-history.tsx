import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Clock, User, MapPin } from "lucide-react";
import type { Swap } from "@shared/schema";

export default function SwapHistory() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  const { data: swaps = [], isLoading: swapsLoading, error } = useQuery({
    queryKey: ["/api/swaps"],
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "completed":
        return "default";
      case "processing":
        return "secondary";
      case "failed":
        return "destructive";
      default:
        return "default";
    }
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 ml-64">
        <Header 
          title="Swap History"
          subtitle="Complete transaction history of battery swaps"
        />
        
        <div className="p-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Swaps</CardTitle>
            </CardHeader>
            <CardContent>
              {swapsLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="animate-pulse border-b border-gray-200 pb-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-2">
                          <div className="h-4 bg-gray-200 rounded w-48"></div>
                          <div className="h-3 bg-gray-200 rounded w-32"></div>
                        </div>
                        <div className="h-6 bg-gray-200 rounded w-20"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (swaps as Swap[]).length > 0 ? (
                <div className="space-y-4">
                  {(swaps as Swap[]).map((swap: Swap) => (
                    <div key={swap.id} className="border-b border-gray-200 pb-4 last:border-b-0">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <ArrowRight className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-900 font-mono">{swap.transactionId}</h3>
                            <p className="text-sm text-gray-500">
                              {new Date(swap.createdAt!).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <Badge variant={getStatusVariant(swap.status)}>
                          {swap.status}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-600">Station:</span>
                          <span className="font-medium">{swap.stationId}</span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <User className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-600">Customer:</span>
                          <span className="font-medium">{swap.customerName || "N/A"}</span>
                        </div>
                        
                        {swap.swapDuration && (
                          <div className="flex items-center space-x-2">
                            <Clock className="w-4 h-4 text-gray-400" />
                            <span className="text-gray-600">Duration:</span>
                            <span className="font-medium">{swap.swapDuration}s</span>
                          </div>
                        )}
                      </div>
                      
                      {(swap.oldBatteryId || swap.newBatteryId) && (
                        <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-center space-x-4 text-sm">
                            {swap.oldBatteryId && (
                              <>
                                <span className="text-gray-600">From:</span>
                                <span className="font-mono font-medium">{swap.oldBatteryId}</span>
                              </>
                            )}
                            {swap.oldBatteryId && swap.newBatteryId && (
                              <ArrowRight className="w-4 h-4 text-gray-400" />
                            )}
                            {swap.newBatteryId && (
                              <>
                                <span className="text-gray-600">To:</span>
                                <span className="font-mono font-medium">{swap.newBatteryId}</span>
                              </>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <ArrowRight className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No swaps yet</h3>
                  <p className="text-gray-600">Battery swap transactions will appear here.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
