import { sql } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  decimal,
  boolean,
  uuid,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - Required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - Required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").notNull().default("operator"), // admin, operator
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Stations table
export const stations = pgTable("stations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  code: varchar("code").notNull().unique(),
  location: varchar("location").notNull(),
  address: text("address"),
  capacity: integer("capacity").notNull(),
  status: varchar("status").notNull().default("online"), // online, offline, maintenance
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Batteries table
export const batteries = pgTable("batteries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  batteryId: varchar("battery_id").notNull().unique(),
  status: varchar("status").notNull().default("available"), // available, charging, in_use, maintenance, in_transit
  chargeLevel: integer("charge_level").notNull().default(0),
  stationId: varchar("station_id").references(() => stations.id),
  slotNumber: integer("slot_number"),
  lastKnownLocation: varchar("last_known_location"), // For tracking battery location
  latitude: decimal("latitude", { precision: 10, scale: 8 }), // Real-time GPS coordinates
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  locationUpdatedAt: timestamp("location_updated_at"), // When location was last updated
  temperatureCelsius: decimal("temperature_celsius", { precision: 5, scale: 2 }),
  healthPercentage: integer("health_percentage").default(100),
  lastSwapAt: timestamp("last_swap_at"),
  lastMaintenanceAt: timestamp("last_maintenance_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Swap history table
export const swaps = pgTable("swaps", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  transactionId: varchar("transaction_id").notNull().unique(),
  stationId: varchar("station_id").notNull().references(() => stations.id),
  operatorId: varchar("operator_id").notNull().references(() => users.id),
  oldBatteryId: varchar("old_battery_id").references(() => batteries.id),
  newBatteryId: varchar("new_battery_id").references(() => batteries.id),
  customerName: varchar("customer_name"),
  customerVehicle: varchar("customer_vehicle"),
  status: varchar("status").notNull().default("completed"), // completed, processing, failed
  swapDuration: integer("swap_duration"), // in seconds
  createdAt: timestamp("created_at").defaultNow(),
});

// Operator check-ins table
export const operatorCheckIns = pgTable("operator_check_ins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  operatorId: varchar("operator_id").notNull().references(() => users.id),
  stationId: varchar("station_id").notNull().references(() => stations.id),
  checkInTime: timestamp("check_in_time").defaultNow(),
  checkOutTime: timestamp("check_out_time"),
  shiftDuration: integer("shift_duration"), // in minutes
});

// Alerts table
export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: varchar("type").notNull(), // low_stock, station_offline, battery_issue, maintenance_required
  title: varchar("title").notNull(),
  message: text("message").notNull(),
  stationId: varchar("station_id").references(() => stations.id),
  batteryId: varchar("battery_id").references(() => batteries.id),
  severity: varchar("severity").notNull().default("medium"), // low, medium, high, critical
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// QR codes table
export const qrCodes = pgTable("qr_codes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: varchar("type").notNull(), // battery, station, slot
  entityId: varchar("entity_id").notNull(),
  qrData: text("qr_data").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Battery location history table
export const batteryLocationHistory = pgTable("battery_location_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  batteryId: varchar("battery_id").notNull().references(() => batteries.id),
  location: varchar("location").notNull(), // Description of location
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  stationId: varchar("station_id").references(() => stations.id),
  slotNumber: integer("slot_number"),
  movedBy: varchar("moved_by").references(() => users.id), // Operator who moved it
  reason: varchar("reason"), // swap, maintenance, relocation, delivery
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const stationRelations = relations(stations, ({ many }) => ({
  batteries: many(batteries),
  swaps: many(swaps),
  alerts: many(alerts),
  operatorCheckIns: many(operatorCheckIns),
}));

export const batteryRelations = relations(batteries, ({ one, many }) => ({
  station: one(stations, {
    fields: [batteries.stationId],
    references: [stations.id],
  }),
  oldSwaps: many(swaps, { relationName: "oldBattery" }),
  newSwaps: many(swaps, { relationName: "newBattery" }),
  alerts: many(alerts),
  locationHistory: many(batteryLocationHistory),
}));

export const batteryLocationHistoryRelations = relations(batteryLocationHistory, ({ one }) => ({
  battery: one(batteries, {
    fields: [batteryLocationHistory.batteryId],
    references: [batteries.id],
  }),
  station: one(stations, {
    fields: [batteryLocationHistory.stationId],
    references: [stations.id],
  }),
  operator: one(users, {
    fields: [batteryLocationHistory.movedBy],
    references: [users.id],
  }),
}));

export const userRelations = relations(users, ({ many }) => ({
  swaps: many(swaps),
  operatorCheckIns: many(operatorCheckIns),
}));

export const swapRelations = relations(swaps, ({ one }) => ({
  station: one(stations, {
    fields: [swaps.stationId],
    references: [stations.id],
  }),
  operator: one(users, {
    fields: [swaps.operatorId],
    references: [users.id],
  }),
  oldBattery: one(batteries, {
    fields: [swaps.oldBatteryId],
    references: [batteries.id],
    relationName: "oldBattery",
  }),
  newBattery: one(batteries, {
    fields: [swaps.newBatteryId],
    references: [batteries.id],
    relationName: "newBattery",
  }),
}));

export const alertRelations = relations(alerts, ({ one }) => ({
  station: one(stations, {
    fields: [alerts.stationId],
    references: [stations.id],
  }),
  battery: one(batteries, {
    fields: [alerts.batteryId],
    references: [batteries.id],
  }),
}));

export const operatorCheckInRelations = relations(operatorCheckIns, ({ one }) => ({
  operator: one(users, {
    fields: [operatorCheckIns.operatorId],
    references: [users.id],
  }),
  station: one(stations, {
    fields: [operatorCheckIns.stationId],
    references: [stations.id],
  }),
}));

// Insert schemas
export const insertStationSchema = createInsertSchema(stations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBatterySchema = createInsertSchema(batteries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSwapSchema = createInsertSchema(swaps).omit({
  id: true,
  transactionId: true,
  createdAt: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

export const insertOperatorCheckInSchema = createInsertSchema(operatorCheckIns).omit({
  id: true,
  checkInTime: true,
});

export const insertQrCodeSchema = createInsertSchema(qrCodes).omit({
  id: true,
  createdAt: true,
});

export const insertBatteryLocationHistorySchema = createInsertSchema(batteryLocationHistory).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Station = typeof stations.$inferSelect;
export type InsertStation = z.infer<typeof insertStationSchema>;
export type Battery = typeof batteries.$inferSelect;
export type InsertBattery = z.infer<typeof insertBatterySchema>;
export type Swap = typeof swaps.$inferSelect;
export type InsertSwap = z.infer<typeof insertSwapSchema>;
export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type OperatorCheckIn = typeof operatorCheckIns.$inferSelect;
export type InsertOperatorCheckIn = z.infer<typeof insertOperatorCheckInSchema>;
export type QrCode = typeof qrCodes.$inferSelect;
export type InsertQrCode = z.infer<typeof insertQrCodeSchema>;
export type BatteryLocationHistory = typeof batteryLocationHistory.$inferSelect;
export type InsertBatteryLocationHistory = z.infer<typeof insertBatteryLocationHistorySchema>;
